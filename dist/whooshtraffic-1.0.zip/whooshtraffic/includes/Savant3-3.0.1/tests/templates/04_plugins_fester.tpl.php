<?php echo $this->fester('Gomez') ?>

<?php echo $this->fester('Morticia') ?>

<?php echo $this->fester('Thing') ?>

