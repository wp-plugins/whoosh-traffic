<?php echo $this->image('savant.gif', 'Savant Template System') ?>

<?php echo $this->image('http://phpsavant.com/etc/fester.jpg') ?>
